package softuni.exam.constants;

public enum Paths {
    ;
    public static  final  String PATH_TO_BOOKS = "src/main/resources/files/json/books.json";
    public static  final  String PATH_TO_MEMBERS = "src/main/resources/files/json/library-members.json";
    public static  final  String PATH_TO_RECORDS = "src/main/resources/files/xml/borrowing-records.xml";
}
