package softuni.exam.constants;

public enum Paths {
    ;
    public static final String PATH_TO_CONSTELLATION = "src/main/resources/files/json/constellations.json";
    public static final String PATH_TO_STARS = "src/main/resources/files/json/stars.json";
    public static final String PATH_TO_ASTRONOMER = "src/main/resources/files/xml/astronomers.xml";
}
