package softuni.exam.models.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import java.util.List;

@Entity
@Table(name = "constellations")
public class Constellation extends BaseEntity{

    @Column(nullable = false)
    @Size(min = 5)
    private String description;

    @Column(unique = true)
    @Size(min = 3,max = 20)
    private String name;

    @OneToMany(mappedBy = "constellation")
    private List<Star> star;

    public Constellation() {
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Star> getStar() {
        return star;
    }

    public void setStar(List<Star> star) {
        this.star = star;
    }
}
