package softuni.exam.constants;

public enum Messages {
    ;
    public static final String VALID_CONSTELLATION_MESSAGE = "Successfully imported %s - %s";
    public static final String INVALID_CONSTELLATION_MESSAGE = "Invalid CONSTELLATION";

    public static final String VALID_STAR_MESSAGE = "Successfully imported %s - %.2f";
    public static final String INVALID_STAR_MESSAGE = "Invalid star";

    public static final String VALID_ASTRONOMER_MESSAGE = "Successfully imported %s %s  - %.2f";
    public static final String INVALID_ASTRONOMER_MESSAGE = "Invalid astronomer";
}
