package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.constants.Messages;
import softuni.exam.constants.Paths;
import softuni.exam.models.dto.AstronomerDto;
import softuni.exam.models.dto.wrapper.AstronomerWrapperDto;
import softuni.exam.models.entity.Astronomer;
import softuni.exam.models.entity.Star;
import softuni.exam.repository.AstronomerRepository;
import softuni.exam.repository.StarRepository;
import softuni.exam.service.AstronomerService;
import softuni.exam.util.ValidationUtils;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static softuni.exam.constants.Messages.INVALID_ASTRONOMER_MESSAGE;
import static softuni.exam.constants.Messages.VALID_ASTRONOMER_MESSAGE;
import static softuni.exam.constants.Paths.PATH_TO_ASTRONOMER;

@Service
public class AstronomerServiceImpl implements AstronomerService {

    private ModelMapper mapper;

    private ValidationUtils validator;

    private AstronomerRepository astronomerRepository;

    private StarRepository starRepository;

    private XmlParser xmlParser;

    @Autowired
    public AstronomerServiceImpl(ModelMapper mapper, ValidationUtils validator, AstronomerRepository astronomerRepository, StarRepository starRepository, XmlParser xmlParser) {
        this.mapper = mapper;
        this.validator = validator;
        this.astronomerRepository = astronomerRepository;
        this.starRepository = starRepository;
        this.xmlParser = xmlParser;
    }

    @Override
    public boolean areImported() {
        return this.astronomerRepository.count()>0;
    }

    @Override
    public String readAstronomersFromFile() throws IOException {
        return Files.readString(Path.of(PATH_TO_ASTRONOMER));
    }

    @Override
    public String importAstronomers() throws IOException, JAXBException {

        StringBuilder builder = new StringBuilder();
        JAXBContext jaxbContext = JAXBContext.newInstance(AstronomerWrapperDto.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        File file = new File(readAstronomersFromFile());

        Reader reader = new FileReader(file);
        AstronomerWrapperDto astronomerWrapperDto = (AstronomerWrapperDto) unmarshaller.unmarshal(reader);

        List<AstronomerDto> astronomerDtos = astronomerWrapperDto.getAstronomerDtos();

        for (AstronomerDto astronomerDto : astronomerDtos) {
            boolean isValid = this.validator.isValid(astronomerDto);

            if(this.astronomerRepository.findFirstByFirstNameAndLastName(astronomerDto.getFirstName(),
                    astronomerDto.getLastName()).isPresent()){
                isValid=false;
            }

            if(this.starRepository.findFirstById(astronomerDto.getObservingStarId()).isEmpty()){
                isValid=false;
            }

            if(isValid){
                Astronomer mapped = this.mapper.map(astronomerDto, Astronomer.class);
                Star star = this.starRepository.findFirstById(astronomerDto.getObservingStarId()).get();
                mapped.setStar(star);

                builder.append(String.format(VALID_ASTRONOMER_MESSAGE,
                        mapped.getFirstName() + mapped.getLastName(),
                        mapped.getAverageObservationHours()));

                this.astronomerRepository.saveAndFlush(mapped);

            }else {
                builder.append(INVALID_ASTRONOMER_MESSAGE)
                        .append(System.lineSeparator());
            }
        }
        return builder.toString();
    }
}