package softuni.exam.constants;

public enum Paths {
    ;
    public static final String PATH_COUNTRIES = "src/main/resources/files/json/countries.json";
    public static final String PATH_VOLCANOES = "src/main/resources/files/json/volcanoes.json";
    public static final String PATH_VOLCANOLOGISTS = "src/main/resources/files/xml/volcanologists.xml";

}
